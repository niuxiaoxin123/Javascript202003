import React from "react";
export default class Search extends React.Component{
    render(){
        return <div>Search</div>
    }
}