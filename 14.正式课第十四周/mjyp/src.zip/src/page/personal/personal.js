import React from "react";
export default class Personal extends React.Component{
    render(){
        return <div>Personal</div>
    }
}