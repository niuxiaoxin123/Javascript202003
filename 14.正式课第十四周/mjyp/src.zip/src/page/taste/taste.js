import React from "react";
export default class Taste extends React.Component{
    render(){
        return <div>Taste</div>
    }
}