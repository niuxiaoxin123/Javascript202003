import React from "react";
export default class Cart extends React.Component{
    render(){
        return <div>Cart</div>
    }
}