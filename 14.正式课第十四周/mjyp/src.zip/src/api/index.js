// 一个模块一个文件
import home from "./home";
export default {
    home
}