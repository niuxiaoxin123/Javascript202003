import React from "react";
export default class Classify extends React.Component{
    render(){
        return <div>Classify</div>
    }
}