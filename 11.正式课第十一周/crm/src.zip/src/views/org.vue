<template>
    <el-container>
        <my-aside :ary="ary"></my-aside>
        <el-main>
            <!-- 凡是能够切换路由发生改变的地方，需要使用router-view -->
            main
            <router-view></router-view>
        </el-main>
    </el-container>
</template>
<script>

// 导入组件
import nav from "@/components/nav.vue";
export default {
  name: '',
  data() { 
    return {
        ary:[]
    }
  },
  components:{
        // 给组件换个名字；
       "my-aside":nav
  }
 }
</script>

<style lang="less" scoped>
 
</style>