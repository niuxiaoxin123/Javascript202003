import * as Types from "../action-types";
export default {
    add(n){
        return {type:Types.ADD_COUNT,n}
    }
}