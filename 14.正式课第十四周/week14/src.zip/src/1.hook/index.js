import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
ReactDOM.render(<div>
    <App a="100"></App>
</div>,document.getElementById("root"));