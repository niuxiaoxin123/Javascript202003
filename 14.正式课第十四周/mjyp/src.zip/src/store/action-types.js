export const HOME_INIT="HOME_INIT";
export const HOME_HOT="HOME_HOT";