<template>
  <el-aside width="200px">

  </el-aside>
</template>

<script>
// vue-loader : 让改文件中html和js，css整合成一个大的对象，然后一起导出；
export default {
  name: 'nav',
  data() { 
    return {

    }
  },
  props:["ary"]
 }
</script>

<style lang="less" scoped>

</style>