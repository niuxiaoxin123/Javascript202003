import {combineReducers} from "redux";
import homeReducer  from "./home.js";
let reducer = combineReducers({
    homeReducer
});
export default reducer;