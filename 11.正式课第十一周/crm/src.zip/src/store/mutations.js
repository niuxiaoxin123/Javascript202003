export function changeDepartmentList(state,option){
    state.departmentList=option
}
export function changeJobList(state,option){
    
}
export function changeUserList(state,option){
    state.userList=option;
}