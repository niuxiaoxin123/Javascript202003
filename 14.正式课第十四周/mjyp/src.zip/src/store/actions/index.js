import homeAction from "./home";
export default {
   home:homeAction
}