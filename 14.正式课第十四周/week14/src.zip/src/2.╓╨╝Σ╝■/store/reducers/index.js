import {combineReducers} from "redux";
import counter from "./counter"
let reducer  = combineReducers({
    counter
});
export default reducer;