export default [
    {
        path:"/crm/my",
        name:"my",
        component:()=>import("@/components/customer/mycustomer.vue")
    },
    {
        path:"/crm/addcustomer",
        name:"addcustomer",
        component:()=>import("@/components/customer/addcus.vue")
    },
    {
        path:"/crm/all",
        name:"all",
        component:()=>import("@/components/customer/allcus.vue")
    }
]