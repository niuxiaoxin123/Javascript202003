<template>
  <div class="hot">
      热榜
  </div>
</template>

<script>
export default {
  name: 'hot',
  data() { 
    return {

    }
  }
 }
</script>

<style lang="less" scoped>
  .hot{

  }
</style>