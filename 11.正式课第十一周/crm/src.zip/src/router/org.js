// 如果是index.vue ;是可以省略的；
import user from "@/components/user";
import addUser from "@/components/user/add.vue";
import department from "@/components/department";
import addDepartment from "@/components/department/adddepartment.vue";
import job from "@/components/job";
import addJob from "@/components/job/addjob.vue";
export default [
    {
        path:"/org/user",
        name:"user",
        component:user
    },
    {
        path:"/org/addUser",
        name:"addUser",
        component:addUser
    },
    {
        path:"/org/department",
        name:"department",
        component:department
    },
    {
        path:"/org/addDepartment",
        name:"addDepartment",
        component:addDepartment
    },
    {
        path:"/org/job",
        name:"job",
        component:job
    },
    {
        path:"/org/addJob",
        name:"addJob",
        component:addJob
    }
    
]