<template>
    <el-container>
        <my-aside :ary="ary"></my-aside>
        <el-main>
            <!-- 凡是能够切换路由发生改变的地方，需要使用router-view -->
            main-crm
            <router-view></router-view>
        </el-main>
    </el-container>
</template>

<script>
import  nav from "@/components/nav.vue";
export default {
  name: '',
  data() { 
    return {
        ary:[]
    }
  },
  components:{
     "my-aside":nav
  }
 }
</script>

<style lang="less" scoped>
 
</style>